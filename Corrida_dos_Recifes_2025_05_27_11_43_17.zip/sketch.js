let fish;
let rocks = [];
let hooks = [];
let corals = [];
let shark;

let faseAtual = 1;
let maxFases = 25;
let goalWallX;
let wallWidth = 20;

let gameState = "title"; // title, playing, gameover, win

function setup() {
  createCanvas(800, 400);
}

function iniciarFase() {
  fish = new Fish(50, height / 2, 5);
  rocks = [];
  hooks = [];
  corals = [];

  goalWallX = fish.pos.x + 700;

  let pathY = random(100, height - 100);
  let nRocks = min(5 + faseAtual * 2, 150);
  for (let i = 0; i < nRocks; i++) {
    let rx = random(fish.pos.x + 100, goalWallX - 50);
    let ry = random(50, height - 50);
    if (abs(ry - pathY) > 40) {
      if (ry < height / 2 && random() < 0.3) {
        hooks.push(new Hook(rx, ry));
      } else {
        rocks.push(new Rock(rx, ry));
      }
    }
  }

  let numCorals = int(random(5, 10));
  for (let i = 0; i < numCorals; i++) {
    let coralY = random(50, height - 50);
    corals.push(coralY);
  }

  let sharkX = fish.pos.x + 400;
  shark = new Shark(sharkX, random(50, height - 50));
}

function draw() {
  background(100, 180, 255);

  if (gameState === "title") {
    drawTitle();
  } else if (gameState === "playing") {
    playGame();
  } else if (gameState === "gameover") {
    drawGameOver();
  } else if (gameState === "win") {
    drawWin();
  }
}

function drawTitle() {
  background(0, 100, 200);
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(40);
  text("🐟 Corrida dos Recifes 🪸", width / 2, height / 2 - 40);
  textSize(20);
  text("Aperte ENTER para começar", width / 2, height / 2 + 20);
}

function drawGameOver() {
  background(0);
  textAlign(CENTER, CENTER);
  fill(255, 0, 0);
  textSize(40);
  text("💀 Game Over!", width / 2, height / 2 - 20);
  textSize(20);
  text("Aperte R para tentar de novo", width / 2, height / 2 + 30);
}

function drawWin() {
  background(0, 180, 100);
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(32);
  text("🏆 Parabéns, todos os peixes estão seguros agora!", width / 2, height / 2 - 20);
  textSize(20);
  text("Aperte R para jogar novamente", width / 2, height / 2 + 30);
}

function playGame() {
  push();
  translate(width / 2 - fish.pos.x, 0);

  fill(20, 80, 40);
  rect(goalWallX, 0, wallWidth, height);

  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  for (let coralY of corals) {
    text("🪸", goalWallX + wallWidth / 2, coralY);
  }

  for (let rock of rocks) {
    rock.show();
    if (rock.hits(fish)) gameState = "gameover";
  }

  for (let hook of hooks) {
    hook.show();
    if (hook.hits(fish)) gameState = "gameover";
  }

  shark.update(fish);
  shark.show();
  if (shark.hits(fish)) gameState = "gameover";

  fish.update();
  fish.show();

  if (fish.pos.x + fish.size / 2 >= goalWallX) {
    if (faseAtual < maxFases) {
      faseAtual++;
      iniciarFase();
    } else {
      gameState = "win";
    }
  }

  pop();

  fill(0);
  textAlign(CENTER);
  textSize(16);
  text("Fase " + faseAtual + "/" + maxFases, width / 2, 30);
}

function keyPressed() {
  if (gameState === "title" && keyCode === ENTER) {
    faseAtual = 1;
    gameState = "playing";
    iniciarFase();
  }

  if ((gameState === "gameover" || gameState === "win") && key === 'r') {
    faseAtual = 1;
    gameState = "playing";
    iniciarFase();
  }

  if (gameState === "playing") {
    if (key === 'D' || key === 'd') fish.setDirection(1, 0);
    if (key === 'W' || key === 'w') fish.setDirection(0, -1);
    if (key === 'S' || key === 's') fish.setDirection(0, 1);
    if (key === 'A' || key === 'a') fish.setDirection(-1, 0);
  }
}

function keyReleased() {
  if (gameState === "playing") {
    fish.setDirection(0, 0);
  }
}

class Fish {
  constructor(x, y, speed) {
    this.pos = createVector(x, y);
    this.vel = createVector(1, 0);
    this.speed = speed;
    this.size = 40;
  }

  setDirection(x, y) {
    this.vel = createVector(x, y).setMag(this.speed);
  }

  update() {
    this.pos.add(this.vel);
    this.pos.y = constrain(this.pos.y, 0, height);
  }

  show() {
    textSize(40);
    textAlign(CENTER, CENTER);
    text("🐟", this.pos.x, this.pos.y);
  }
}

class Rock {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.size = 30;
  }

  hits(fish) {
    return dist(fish.pos.x, fish.pos.y, this.pos.x, this.pos.y) < this.size;
  }

  show() {
    textSize(30);
    textAlign(CENTER, CENTER);
    text("🪨", this.pos.x, this.pos.y);
  }
}

class Hook {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.size = 30;
  }

  hits(fish) {
    return dist(fish.pos.x, fish.pos.y, this.pos.x, this.pos.y) < this.size;
  }

  show() {
    fill(255, 0, 0);
    textSize(32);
    text("🪝", this.pos.x, this.pos.y);
    stroke(255);
    strokeWeight(2);
    line(this.pos.x, this.pos.y - 10, this.pos.x, this.pos.y - 60);
  }
}

class Shark {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.size = 50;
    this.speed = 0.4;
  }

  update(fish) {
    let direction = createVector(fish.pos.x - this.pos.x, fish.pos.y - this.pos.y);
    direction.normalize().mult(this.speed);
    this.pos.add(direction);
  }

  hits(fish) {
    return dist(fish.pos.x, fish.pos.y, this.pos.x, this.pos.y) < this.size;
  }

  show() {
    textSize(40);
    text("🦈", this.pos.x, this.pos.y);
  }
}
